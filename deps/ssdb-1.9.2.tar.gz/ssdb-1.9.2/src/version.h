#ifndef SSDB_DEPS_H
#ifndef SSDB_VERSION
#define SSDB_VERSION "1.9.2"
#endif
#endif
#ifndef IOS
#include <stdlib.h>
#include <jemalloc/jemalloc.h>
#endif
